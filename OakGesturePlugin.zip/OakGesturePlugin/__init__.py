import os
import sys
import subprocess
from pymol.plugins import addmenuitemqt

dialog = None

def __init_plugin__(app=None):
    addmenuitemqt('OAK Plugin (PyQt)', run_plugin_gui)

def run_plugin_gui():
    from pymol.Qt import QtWidgets
    from pymol.Qt.utils import loadUi
    global dialog

    if dialog is None:
        dialog = QtWidgets.QDialog()

        # Twardo zakodowana ścieżka do pliku .ui
        uifile = r"C:\Users\LENOVO\Documents\Work_Space\PyMol_Plugin\OakGesturePlugin\OakGesturePlugin\demowidget.ui"
        form = loadUi(uifile, dialog)

        def run():
            print("▶ Uruchamiam oak_plugin.py przez subprocess!")

            # Twardo zakodowana ścieżka do interpretera Pythona
            python_path = r"C:\Users\LENOVO\Documents\Work_Space\PyMol_Plugin\en38\Scripts\python.exe"

            # Twardo zakodowana ścieżka do skryptu oak_plugin.py
            script_path = r"C:\Users\LENOVO\Documents\Work_Space\PyMol_Plugin\plugin_directory\oak_plugin.py"

            if not os.path.isfile(script_path):
                print(f"❌ Nie znaleziono pliku: {script_path}")
                return

            try:
                subprocess.Popen([python_path, script_path])
                print("🌿 Oak gesture system started.")
            except Exception as e:
                print(f"❌ Failed to start gesture system: {e}")

        try:
            if hasattr(form, 'button_start'):
                form.button_start.clicked.connect(run)
            else:
                print("⚠️ [Plugin Warning] Nie znaleziono przycisku 'button_start' w demowidget.ui")
        except AttributeError:
            print("❌ Nie znaleziono przycisku `button_start` w demowidget.ui")

    dialog.show()
